import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
import math

label_list = ["Explosion", "Not Explosion"]  #改曲線名稱
num = 2
mu_list = [115.9412, 48.40288]     # 直接依序填入平均值
sigma_list = [77.412, 34.72286]  # 直接依序填入標準差
#for i in range(num):
    #mu_list.append(float(input("請輸入平均值: ")))
    #sigma_list.append(float(input("請輸入標準差: ")))
i = 0
fig, ax = plt.subplots(2, 1)
x = np.linspace(mu_list[0] - 3*sigma_list[0], mu_list[0] + 3*sigma_list[0], 100)
y = np.linspace(mu_list[1] - 3*sigma_list[1], mu_list[1] + 3*sigma_list[1], 100)
ax[0].plot(x, stats.norm.pdf(x, mu_list[0], sigma_list[0]))
ax[1].plot(y, stats.norm.pdf(y, mu_list[1], sigma_list[1]))
ax[0].set_xlabel('upvote (Explosion)')
ax[0].set_ylabel('probability')
ax[1].set_xlabel('upvote (not-explosion)')
ax[1].set_ylabel('probability ')
#plt.xlim(left=0)
#plt.legend()
print("Plotting the Graph...")
plt.show()
while (1):
    para = float(input("輸入欲量測之點: "))
    x = np.linspace(mu_list[0]- 3*sigma_list[0], mu_list[0] + 3*sigma_list[0], 100)
    y = np.linspace(mu_list[1]- 3*sigma_list[1], mu_list[1] + 3*sigma_list[1], 100)
    print(label_list[0], "機率: ", stats.norm.pdf(para, mu_list[0], sigma_list[0]))
    print(label_list[1], "機率: ", stats.norm.pdf(para, mu_list[1], sigma_list[1]))