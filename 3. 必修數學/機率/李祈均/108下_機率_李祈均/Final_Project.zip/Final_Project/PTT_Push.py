import requests
from requests_html import HTML
import urllib.parse
from re import findall
from pandas import DataFrame
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt

domain = 'https://www.ptt.cc/'

def parse_article_entries(doc):
    html = HTML(html=doc)
    post_entries = html.find('div.r-ent')
    return post_entries

def parse_comments(doc):
    html = HTML(html=doc)
    comments = html.find('div.push')
    comment_time = html.find('span.push-ipdatetime')
    post_time = html.find('span.article-meta-value')
    return comments, comment_time, post_time

def parse_link_meta(ent):
    meta = {
        'link': ent.find('div.title > a', first=True).attrs['href']
    }
    return meta

def get_metadata_from():
    board_name = input("請輸入欲搜尋之看板: ")
    search_endpoint_url = 'https://www.ptt.cc/bbs/' + board_name + '/search'
    article_name = input("請輸入欲搜尋之文章名稱: ")
    resp = requests.get(search_endpoint_url, params={'q': article_name})
    post_entries = parse_article_entries(resp.text)
    link_data = [parse_link_meta(entry) for entry in post_entries]
    return link_data

def analyze_data(comment_time, post_time, interval, duration):
    t = np.arange(0, int(duration)+int(interval), int(interval))
    num = np.zeros(int(int(duration)/int(interval)+1))
    time_2 = findall(r'\d+', post_time[3].text)     # 格式為 星期幾 月 日 時:分:秒 年分
    dt2 = datetime(2019, 5, int(time_2[0]), int(time_2[1]), int(time_2[2]), 0, 0)
    #print(post_time[3].text)
    for c_time in comment_time:
        time_1 = findall(r'\d+', c_time.text)    # 格式為 月 日 時 分
        dt1 = datetime(2019, int(time_1[0]), int(time_1[1]), int(time_1[2]), int(time_1[3]), 0, 0)
        differ = (dt1 - dt2).seconds/60
        num[int(differ/int(interval))] += 1
        #print(c_time.text, differ)
    plt.plot(t,num)
    plt.xlabel("time since posted(min)")
    plt.ylabel("Comments every "+interval+" minutes")
    plt.show()
    output = input("是否要輸出csv檔? (Y/N): ")
    if (output == "Y"):
        out_data = list(zip(t, num))
        file_name = input("請輸入檔名(不用加.csv): ")
        df = DataFrame(out_data)
        df.to_csv(file_name + ".csv", sep=',', header=None, index=None)

    

def count_voting(link, interval, duration):
    url = urllib.parse.urljoin(domain, link['link']) 
    resp = requests.get(url)
    comments, comment_time, post_time = parse_comments(resp.text)
    analyze_data(comment_time, post_time, interval, duration)
    total = len(comments)
    print("總回文數: ", total)

links = get_metadata_from()
interval = input("希望作圖的時間間隔: (單位: 分鐘) ")
duration = input("抓取的時間範圍: (單位: 分鐘) ")
for link in links:
    count_voting(link, interval, duration)
