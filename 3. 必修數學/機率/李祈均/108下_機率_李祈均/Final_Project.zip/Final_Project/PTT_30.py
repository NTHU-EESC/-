import requests
from requests_html import HTML
import urllib.parse
from re import findall
from pandas import DataFrame
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt

domain = 'https://www.ptt.cc/'
post_month = 6  #依據發文者當時的月份為基準

def parse_article_entries(doc):
    html = HTML(html=doc)
    post_entries = html.find('div.r-ent')
    return post_entries

def parse_comments(doc):
    html = HTML(html=doc)
    comments = html.find('div.push')
    comment_time = html.find('span.push-ipdatetime')
    post_time = html.find('span.article-meta-value')
    return comments, comment_time, post_time

def parse_link_meta(ent):
    meta = {
        'link': ent.find('div.title > a', first=True).attrs['href']
    }
    return meta

def get_metadata_from():
    board_name = "NBA"
    search_endpoint_url = 'https://www.ptt.cc/bbs/' + board_name + '/search'
    article_name = input("請輸入欲搜尋之文章名稱: ")
    resp = requests.get(search_endpoint_url, params={'q': article_name})
    post_entries = parse_article_entries(resp.text)
    link_data = [parse_link_meta(entry) for entry in post_entries]
    return link_data

def analyze_data(comment_time, post_time):
    print("該文發文時間: ", post_time[3].text)
    counter = 0
    time_2 = findall(r'\d+', post_time[3].text)     # 格式為 星期幾 月 日 時:分:秒 年分
    dt2 = datetime(2019, post_month, int(time_2[0]), int(time_2[1]), int(time_2[2]), 0, 0)
    for c_time in comment_time:
        time_1 = findall(r'\d+', c_time.text)    # 格式為 月 日 時 分
        dt1 = datetime(2019, int(time_1[0]), int(time_1[1]), int(time_1[2]), int(time_1[3]), 0, 0)
        differ = (dt1 - dt2).seconds/60
        if differ <= 30:
            counter += 1
        else:
            break
    print("前30分鐘回文數: ", counter)

def count_voting(link):
    url = urllib.parse.urljoin(domain, link['link']) 
    resp = requests.get(url)
    comments, comment_time, post_time = parse_comments(resp.text)
    analyze_data(comment_time, post_time)
    total = len(comments)
    print("總回文數: ", total)

print("已在NBA版")
while (1):
    links = get_metadata_from()
    for link in links:
        count_voting(link)
