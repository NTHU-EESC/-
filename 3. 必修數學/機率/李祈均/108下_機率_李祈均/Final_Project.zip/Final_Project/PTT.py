import requests
import sys
from requests_html import HTML
from pandas import DataFrame
import time

domain = 'https://www.ptt.cc/'

def parse_board_entries(doc):
    html = HTML(html=doc)
    board_entries = html.find('div.b-ent')
    return board_entries

def fetch(url):
    response = requests.get(url)
    response = requests.get(url, cookies={'over18': '1'})  # 一直向 server 回答滿 18 歲了 !
    return response

def parse_board_meta(entry):
    '''
    每筆資料都存在 dict() 類型中：key-value paird data
    '''
    return {
        'title': entry.find('div.board-name', first=True).text,
        'users': entry.find('div.board-nuser', first=True).text,
        'link': entry.find('a', first=True).attrs['href'],
    }

sys.setrecursionlimit(10000000)
interval = input("輸入取樣的區間: (分鐘)")
sleep_time = int(interval)*60
i = 0
while (i < 500):
    url = 'https://www.ptt.cc/bbs/hotboards.html'
    resp = fetch(url)  # step-1
    board_entries = parse_board_entries(resp.text)  # step-2

    metadata = []
    for entry in board_entries:
        meta = parse_board_meta(entry)
        metadata.append(meta)
        #print(meta['title'], meta['users'], meta['link'])
    cur_time = time.strftime("%Y-%m-%d %H %M %S", time.localtime())
    df = DataFrame(metadata)
    df.to_csv("out" + str(i) + " " + cur_time + ".csv", sep=',', header=None, index=None, encoding='utf_8_sig')
    print("batch " + str(i) + " completed!")
    time.sleep(int(sleep_time))
    i += 1
