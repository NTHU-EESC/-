import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
import math

label_list = "Explosion"  #改曲線名稱
num = 2
mu = 123.34     # 直接依序填入平均值
sigma = 89.65  # 直接依序填入標準差
#for i in range(num):
    #mu_list.append(float(input("請輸入平均值: ")))
    #sigma_list.append(float(input("請輸入標準差: ")))
x = np.linspace(mu - 3*sigma, mu + 3*sigma, 100)
plt.plot(x, stats.norm.pdf(x, mu, sigma), label = label_list)
plt.xlim(left=0)
plt.legend()
print("Plotting the Graph...")
plt.show()
'''
while (1):
    para = float(input("輸入欲量測之點: "))
    i = 0
    for mu, sigma in mu_list, sigma_list:
        x = np.linspace(mu - 3*sigma, mu + 3*sigma, 100)
        print(label_list[i], "機率: ", stats.norm.pdf(para, mu, sigma))
        i += 1
  '''      