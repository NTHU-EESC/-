function X = dftdirect_m(x, W)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
    X = W*x.';
end

