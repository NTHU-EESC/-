#ifndef _MAIN_CACHE_HPP_
#define _MAIN_CACHE_HPP_

#include "base_cache.hpp"
#include <ctime>
#include <queue>
#include <random>

typedef struct block_inf {
    ulint idx;
    ulint freq;
} block_inf;

typedef struct acess_order {
    ulint idx;
    ulint va;
} acess_order;

class MainCache : public BaseCache {
  public:
    explicit MainCache(const CacheProperty &);
    ~MainCache();
    bool Get(const addr_t &);
    bool Set(const addr_t &);
    bool IsHit(const addr_t &);

  protected:
    void _HitHandle(const addr_t &);
    void _Replace(const addr_t &);
    ulint _GetCacheBlockIndex(const addr_t &addr);
    ulint _GetIndexByLFU(const addr_t &addr);
    ulint _GetIndexByRandom(const addr_t &addr);
    ulint _GetSetNumber(const addr_t &addr);

    std::vector<block_inf> _LFU_priority;
    std::vector<ulint> order;
};

#endif
